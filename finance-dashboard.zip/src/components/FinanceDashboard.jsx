import { useCallback, useEffect, useMemo, useState } from 'react'
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  BarChart,
  Bar,
  Legend,
  PieChart,
  Pie,
  Cell,
} from 'recharts'

import ChartCard from './ChartCard'
import DonutLegend from './DonutLegend'
import KpiCard from './KpiCard'
import { mockDashboard } from '../data/mockDashboard'
import { formatCurrency, formatPercent } from '../utils/formatters'

const normalizeKpi = (entry) => {
  if (entry && typeof entry === 'object') {
    return {
      value: entry.value ?? null,
      trend: entry.trend ?? entry.trendPercentage ?? null,
    }
  }
  if (typeof entry === 'number') {
    return { value: entry, trend: null }
  }
  return { value: null, trend: null }
}

const FinanceDashboard = () => {
  const [dashboardData, setDashboardData] = useState(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const [reportState, setReportState] = useState({ loading: false, message: null })

  const loadDashboard = useCallback(async () => {
    try {
      setLoading(true)
      setError(null)
      const response = await fetch('/api/v1/finance/dashboard')
      if (!response.ok) {
        throw new Error('Unable to reach finance dashboard API')
      }
      const payload = await response.json()
      setDashboardData(payload)
    } catch (err) {
      console.warn('[FinanceDashboard] Falling back to mock data:', err.message)
      setDashboardData(mockDashboard)
      setError('Live data is unavailable. Showing synchronized mock snapshot instead.')
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    loadDashboard()
  }, [loadDashboard])

  const handleGenerateReport = async () => {
    try {
      setReportState({ loading: true, message: null })
      const response = await fetch('/api/v1/finance/report/generate')
      if (!response.ok) {
        throw new Error('Report download failed')
      }
      const blob = await response.blob()
      const disposition = response.headers.get('Content-Disposition')
      const match = disposition?.match(/filename="?(.+)"?/)
      const fallbackName = `finance-report-${new Date().toISOString().slice(0, 10)}.pdf`
      const fileName = match?.[1] ?? fallbackName

      const url = window.URL.createObjectURL(blob)
      const link = document.createElement('a')
      link.href = url
      link.setAttribute('download', fileName)
      document.body.appendChild(link)
      link.click()
      link.remove()
      window.URL.revokeObjectURL(url)

      setReportState({ loading: false, message: 'Report downloaded successfully.' })
    } catch (err) {
      setReportState({ loading: false, message: 'Unable to download report right now.' })
    }
  }

  const data = dashboardData ?? mockDashboard
  const disbursementTrends = data?.disbursementTrends ?? []
  const collectionPerformance = data?.collectionPerformance ?? []
  const paymentStatusDistribution = data?.paymentStatusDistribution ?? []
  const loanPortfolioComposition = data?.loanPortfolioComposition ?? []
  const lastSynced = useMemo(() => {
    try {
      return data.generatedAt
        ? new Date(data.generatedAt).toLocaleString()
        : new Date().toLocaleString()
    } catch {
      return new Date().toLocaleString()
    }
  }, [data.generatedAt])

  const kpiItems = [
    {
      key: 'totalDisbursed',
      label: 'Total Disbursed',
      helper: 'Cumulative for selected period',
      formatter: formatCurrency,
    },
    {
      key: 'pendingDisbursement',
      label: 'Pending Disbursement',
      helper: 'Approved & awaiting release',
      formatter: formatCurrency,
    },
    {
      key: 'collectionRate',
      label: 'Collection Rate',
      helper: 'Expected vs actual receipts',
      formatter: (value) => formatPercent(value ?? 0, { digits: 0 }),
    },
    {
      key: 'overdueAmount',
      label: 'Overdue Amount',
      helper: 'Principal + interest past due',
      formatter: formatCurrency,
    },
  ]

  return (
    <div className="min-h-screen bg-brand-surface pb-14">
      <div className="mx-auto max-w-7xl px-6 py-10">
        <header className="flex flex-wrap items-start justify-between gap-6">
          <div>
            <p className="text-sm uppercase tracking-wide text-slate-500">
              BRD Portal / Finance
            </p>
            <h1 className="mt-1 text-3xl font-semibold text-white">
              Finance Operations Dashboard
            </h1>
            <p className="mt-2 text-sm text-slate-400">
              Last synchronized: <span className="text-slate-200">{lastSynced}</span>
            </p>
          </div>
          <div className="flex flex-wrap gap-3">
            <button
              onClick={loadDashboard}
              disabled={loading}
              className="rounded-full border border-white/20 px-4 py-2 text-sm font-semibold text-white transition hover:border-brand-accent hover:text-brand-accent disabled:opacity-50"
            >
              {loading ? 'Refreshing…' : 'Refresh Data'}
            </button>
            <button
              onClick={handleGenerateReport}
              disabled={reportState.loading}
              className="rounded-full bg-brand-accent px-5 py-2 text-sm font-semibold text-slate-900 shadow-lg shadow-sky-500/30 transition hover:bg-sky-300 disabled:opacity-50"
            >
              {reportState.loading ? 'Generating…' : 'Generate Report'}
            </button>
          </div>
        </header>

        {error ? (
          <div className="mt-6 rounded-2xl border border-amber-500/30 bg-amber-500/10 px-4 py-3 text-sm text-amber-200">
            {error}
          </div>
        ) : null}

        {reportState.message ? (
          <p className="mt-3 text-xs text-slate-400">{reportState.message}</p>
        ) : null}

        <section className="mt-8 grid gap-4 md:grid-cols-2 xl:grid-cols-4">
          {kpiItems.map((item) => {
            const normalized = normalizeKpi(data?.kpis?.[item.key])
            return (
              <KpiCard
                key={item.key}
                label={item.label}
                value={normalized.value}
                helper={item.helper}
                trend={normalized.trend}
                formatter={item.formatter}
              />
            )
          })}
        </section>

        <section className="mt-8 grid gap-6 lg:grid-cols-2">
          <ChartCard
            title="Disbursement Trends"
            subtitle="Monthly disbursements (₹ in Millions)"
          >
            <div className="h-72">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={disbursementTrends}>
                  <defs>
                    <linearGradient id="colorDisbursed" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#38bdf8" stopOpacity={0.8} />
                      <stop offset="95%" stopColor="#38bdf8" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                  <XAxis dataKey="month" stroke="#94a3b8" />
                  <YAxis
                    stroke="#94a3b8"
                    tickFormatter={(value) => `${value}M`}
                    width={60}
                  />
                  <Tooltip
                    contentStyle={{ backgroundColor: '#0f172a', border: 'none' }}
                    labelStyle={{ color: '#cbd5f5' }}
                    formatter={(value) => [`${value}M`, 'Disbursed']}
                  />
                  <Line
                    type="monotone"
                    dataKey="disbursed"
                    stroke="#38bdf8"
                    strokeWidth={3}
                    dot={{ r: 4 }}
                    activeDot={{ r: 6 }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </ChartCard>

          <ChartCard
            title="Collection Performance"
            subtitle="Expected vs actual collections (₹ in Millions)"
          >
            <div className="h-72">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={collectionPerformance}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                  <XAxis dataKey="month" stroke="#94a3b8" />
                  <YAxis
                    stroke="#94a3b8"
                    tickFormatter={(value) => `${value}M`}
                    width={60}
                  />
                  <Tooltip
                    contentStyle={{ backgroundColor: '#0f172a', border: 'none' }}
                    labelStyle={{ color: '#cbd5f5' }}
                  />
                  <Legend />
                  <Bar dataKey="expected" fill="#22d3ee" radius={[6, 6, 0, 0]} />
                  <Bar dataKey="actual" fill="#0ea5e9" radius={[6, 6, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </ChartCard>
        </section>

        <section className="mt-8 grid gap-6 lg:grid-cols-2">
          <ChartCard
            title="Payment Status Distribution"
            subtitle="Share of outstanding loans by repayment status"
          >
            <div className="flex flex-col items-center justify-center gap-4 lg:flex-row">
              <div className="h-72 w-full lg:w-1/2">
                <ResponsiveContainer>
                  <PieChart>
                    <Pie
                      data={paymentStatusDistribution}
                      dataKey="value"
                      nameKey="status"
                      innerRadius={70}
                      outerRadius={110}
                      stroke="none"
                    >
                      {paymentStatusDistribution.map((entry) => (
                        <Cell key={entry.status} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip
                      formatter={(value, name) => [`${value}%`, name]}
                      contentStyle={{ backgroundColor: '#0f172a', border: 'none' }}
                    />
                  </PieChart>
                </ResponsiveContainer>
              </div>
              <div className="w-full lg:w-1/2">
                <DonutLegend
                  items={paymentStatusDistribution.map((item) => ({
                    label: item.status,
                    value: item.value,
                    color: item.color,
                  }))}
                />
              </div>
            </div>
          </ChartCard>

          <ChartCard
            title="Loan Portfolio Composition"
            subtitle="Outstanding value grouped by loan purpose"
          >
            <div className="flex flex-col items-center justify-center gap-4 lg:flex-row">
              <div className="h-72 w-full lg:w-1/2">
                <ResponsiveContainer>
                  <PieChart>
                    <Pie
                      data={loanPortfolioComposition}
                      dataKey="value"
                      nameKey="type"
                      innerRadius={70}
                      outerRadius={110}
                      stroke="none"
                    >
                      {loanPortfolioComposition.map((entry) => (
                        <Cell key={entry.type} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip
                      formatter={(value, name) => [`${value}%`, name]}
                      contentStyle={{ backgroundColor: '#0f172a', border: 'none' }}
                    />
                  </PieChart>
                </ResponsiveContainer>
              </div>
              <div className="w-full lg:w-1/2">
                <DonutLegend
                  items={loanPortfolioComposition.map((item) => ({
                    label: item.type,
                    value: item.value,
                    color: item.color,
                  }))}
                />
              </div>
            </div>
          </ChartCard>
        </section>
      </div>
    </div>
  )
}

export default FinanceDashboard

