import { formatTrend } from '../utils/formatters'

const Arrow = ({ direction = 'up' }) => {
  const rotation = direction === 'up' ? 'rotate(-45 12 12)' : 'rotate(135 12 12)'
  return (
    <svg
      viewBox="0 0 24 24"
      className="h-4 w-4 fill-none stroke-current"
      strokeWidth={2}
      aria-hidden="true"
    >
      <g transform={rotation}>
        <path d="M12 5v14" />
        <path d="M5 12h14" />
      </g>
    </svg>
  )
}

const TrendBadge = ({ trend }) => {
  if (trend === null || trend === undefined) return null
  const isPositive = trend >= 0
  return (
    <span
      className={`inline-flex items-center gap-1 rounded-full px-2 py-1 text-xs font-semibold ${
        isPositive ? 'bg-emerald-500/15 text-emerald-400' : 'bg-rose-500/15 text-rose-400'
      }`}
    >
      <Arrow direction={isPositive ? 'up' : 'down'} />
      {formatTrend(trend)}
    </span>
  )
}

const KpiCard = ({ label, value, helper, trend, formatter = (val) => val }) => {
  const formattedValue =
    value === null || value === undefined ? '—' : formatter(value)

  return (
    <div className="rounded-2xl bg-brand-card/80 p-5 shadow-glow ring-1 ring-white/5">
      <div className="flex items-start justify-between">
        <div>
          <p className="text-sm font-medium text-slate-400">{label}</p>
          <p className="mt-3 text-3xl font-semibold text-white">{formattedValue}</p>
        </div>
        <TrendBadge trend={typeof trend === 'number' ? trend : null} />
      </div>
      {helper ? (
        <p className="mt-4 text-xs text-slate-400">{helper}</p>
      ) : null}
    </div>
  )
}

export default KpiCard

