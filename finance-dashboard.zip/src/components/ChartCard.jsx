const ChartCard = ({ title, subtitle, children, actions }) => (
  <div className="flex h-full flex-col rounded-2xl bg-brand-card/80 p-5 shadow-glow ring-1 ring-white/5">
    <div className="mb-4 flex items-start justify-between gap-3">
      <div>
        <p className="text-lg font-semibold text-white">{title}</p>
        {subtitle ? <p className="text-sm text-slate-400">{subtitle}</p> : null}
      </div>
      {actions ? <div className="shrink-0">{actions}</div> : null}
    </div>
    <div className="flex-1">{children}</div>
  </div>
)

export default ChartCard

