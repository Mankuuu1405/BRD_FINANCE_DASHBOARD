export const mockDashboard = {
  generatedAt: '2025-06-01T09:00:00.000Z',
  kpis: {
    totalDisbursed: { value: 25_800_000, trend: 8.4 },
    pendingDisbursement: { value: 4_200_000, trend: -3.2 },
    collectionRate: { value: 0.92, trend: 1.1 },
    overdueAmount: { value: 1_200_000, trend: 0.9 },
  },
  disbursementTrends: [
    { month: 'Jan', disbursed: 3.2 },
    { month: 'Feb', disbursed: 3.8 },
    { month: 'Mar', disbursed: 4.1 },
    { month: 'Apr', disbursed: 4.3 },
    { month: 'May', disbursed: 4.8 },
    { month: 'Jun', disbursed: 5.2 },
  ],
  collectionPerformance: [
    { month: 'Jan', expected: 3.0, actual: 2.8 },
    { month: 'Feb', expected: 3.5, actual: 3.4 },
    { month: 'Mar', expected: 3.8, actual: 3.6 },
    { month: 'Apr', expected: 4.0, actual: 3.7 },
    { month: 'May', expected: 4.3, actual: 4.1 },
    { month: 'Jun', expected: 4.6, actual: 4.3 },
  ],
  paymentStatusDistribution: [
    { status: 'On Time', value: 70, color: '#22c55e' },
    { status: '30-60 Days Overdue', value: 15, color: '#fb923c' },
    { status: '60+ Days Overdue', value: 10, color: '#f97316' },
    { status: 'Default', value: 5, color: '#ef4444' },
  ],
  loanPortfolioComposition: [
    { type: 'Business Loans', value: 45, color: '#14b8a6' },
    { type: 'Personal Loans', value: 30, color: '#3b82f6' },
    { type: 'Home Loans', value: 15, color: '#a855f7' },
    { type: 'Vehicle Loans', value: 10, color: '#facc15' },
  ],
}

