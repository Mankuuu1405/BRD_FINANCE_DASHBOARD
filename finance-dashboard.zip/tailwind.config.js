/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      fontFamily: {
        sans: ['Inter', 'system-ui', 'Helvetica Neue', 'Arial', 'sans-serif'],
      },
      colors: {
        brand: {
          surface: '#0f172a',
          card: '#111c33',
          accent: '#38bdf8',
          accentMuted: '#1d4ed8',
          warning: '#f97316',
          danger: '#ef4444',
        },
      },
      boxShadow: {
        glow: '0 20px 45px rgba(15, 23, 42, 0.55)',
      },
    },
  },
  plugins: [],
}
